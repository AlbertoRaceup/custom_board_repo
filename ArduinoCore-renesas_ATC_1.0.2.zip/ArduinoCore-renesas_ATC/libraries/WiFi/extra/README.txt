Compile using esp-idf v5.1-dev-3462-g045163a2ec
