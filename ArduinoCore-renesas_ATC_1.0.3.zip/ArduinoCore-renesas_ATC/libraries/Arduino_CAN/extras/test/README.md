`CAN/test`
==========
This directory contains CAN library test code for compilation and execution on host.

#### How-to-build/run
```bash
mkdir build && cd build
cmake ..
make && bin/can-test
```
