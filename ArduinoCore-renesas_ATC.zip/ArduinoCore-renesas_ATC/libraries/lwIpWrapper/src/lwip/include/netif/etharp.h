/* ARP has been moved to core/ipv4, provide this #include for compatibility only */
#include "etharp.h"
#include "../netif/ethernet.h"
